package com.example.demo;

import domain.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import repository.ProductRepository;
import service.ProductService;

public class HelloController {

    @FXML
    private TableView<Product> productTable;

    @FXML
    private TableColumn<Product, Integer> colId;

    @FXML
    private TableColumn<Product, String> colName;

    @FXML
    private TableColumn<Product, String> colCategory;

    @FXML
    private TableColumn<Product, Double> colPrice;

    @FXML
    private TextField categoryField;

    private ProductService service;
    private ObservableList<Product> model = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        ProductRepository repo = new ProductRepository("jdbc:sqlite:./identifier.sqlite");
        service = new ProductService(repo);

        colId.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        colName.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getName()));
        colCategory.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getCategory()));
        colPrice.setCellValueFactory(cellData -> new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().getPrice()).asObject());

        productTable.setItems(model);

        model.setAll(service.getAllProducts());
    }

    @FXML
    protected void onFilterButtonClick() {
        String category = categoryField.getText();
        model.setAll(service.filterByCategory(category));
    }

    @FXML
    protected void onResetButtonClick() {
        categoryField.clear();
        model.setAll(service.getAllProducts());
    }
}
