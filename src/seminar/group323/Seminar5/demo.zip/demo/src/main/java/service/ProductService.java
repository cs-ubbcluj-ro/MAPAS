package service;

import domain.Product;
import repository.ProductRepository;

import java.util.List;

public class ProductService {
    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    public List<Product> filterByCategory(String category) {
        if (category == null || category.isBlank()) {
            return repo.findAll();
        }
        return repo.findByCategorySorted(category.trim());
    }
}
